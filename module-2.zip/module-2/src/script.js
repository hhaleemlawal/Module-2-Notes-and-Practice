document.getElementsByTagName("h1")[0].style.fontSize = "6vw";
<script src="scripts/main.js"></script>
Const keybord={
  name: "keybord",
  weight: 2,
  color:"black"
  
}
Var container 5
container
let a = 5;
let b = 4;

console.log(`let a: ${a} (${typeof a})`);
console.log(`let b: ${b} (${typeof b})`);

if (a == b) {
  console.log(`Match! let a and let b are the same value.`);
} else {
  console.error(`No match: let a and let b are NOT same value.`);
}
let a = 8;
let b = 5;
let c = 7.2;

console.log(`let a: ${a} (${typeof a})`);
console.log(`let b: ${b} (${typeof b})`);
console.log(`let c: ${c} (${typeof c})`);

let result = a + b/c;


const collection = ["Mouse", item, 5, true];

console.log(collection[2]);
backpackContent.pop()

const array=["mouse","textbook","notepad","keyboard","pen"]

    
Function declaration:
function doSomeMath(a, b) {
  let c = a - b;
  return c;
}

// Function expression:
const doMoreMath = function (a = 10, b = 5) {
  let c = a * b;
  return c;
};
const tipCalculator = (sum, percentage) => {
  let sum = 95.95;
  let percentage = 18;
  let tip = sum * (percentage / 100);
  let total = sum + tip;
  console.log(`
  Sum before tip: ${sum}
  Tip percentage: ${percentage}%
  Tip:            ${tip.toFixed(2)}
  Total:          ${total.toFixed(2)}
`);
};

tipCalculator();